package com.barun.testfeign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestfeignApplicationTests {

	@Test
	void contextLoads() {
	}

}
