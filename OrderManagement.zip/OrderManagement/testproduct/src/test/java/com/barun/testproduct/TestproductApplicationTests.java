package com.barun.testproduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestproductApplicationTests {

	@Test
	void contextLoads() {
	}

}
