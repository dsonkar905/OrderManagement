package com.poc.testproduct.service;

import java.util.List;

import com.poc.testproduct.entity.OrderEntity;

public interface OrderService {
	String createOrder(OrderEntity order);
	
	List<OrderEntity> getOrderByName(String customerName);
	
	OrderEntity getOrderByOrderId(Long orderId);
}
