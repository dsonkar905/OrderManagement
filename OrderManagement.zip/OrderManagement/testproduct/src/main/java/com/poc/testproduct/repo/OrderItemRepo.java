package com.poc.testproduct.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.poc.testproduct.entity.OrderItemEntity;

public interface OrderItemRepo extends JpaRepository<OrderItemEntity, Long>{

}
