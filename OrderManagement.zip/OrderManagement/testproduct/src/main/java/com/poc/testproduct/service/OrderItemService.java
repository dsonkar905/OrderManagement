package com.poc.testproduct.service;

import java.util.List;

import com.poc.testproduct.entity.OrderItemEntity;

public interface OrderItemService {
	String createOrderItem(OrderItemEntity orderItem);
	List<OrderItemEntity> getAllItemEntity();
    OrderItemEntity getOrderItemByProductCode(String productCode);
    OrderItemEntity getOrderItemByItemId(String itemId);
}
