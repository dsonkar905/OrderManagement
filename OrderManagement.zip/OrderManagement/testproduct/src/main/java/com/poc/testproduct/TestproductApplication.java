package com.poc.testproduct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;

@SpringBootApplication
@Configuration
public class TestproductApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestproductApplication.class, args);
	}

}
